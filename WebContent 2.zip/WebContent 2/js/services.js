'use strict';

/*services*/

var bookServices = angular.module('bookServices', ['ngResource']);

bookServices.factory('', ['$resource', function($resource) {
	return
}]);